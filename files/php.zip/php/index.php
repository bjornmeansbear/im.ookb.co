<!DOCTYPE html>

<!-- This is a PHP file, notice that it looks very similar to a regular HTML file � this is not always the case, but mostly is true when just working on theme-related endeavors.-->
<html>

  <head>
    <title>PHP Demo</title>
  </head>

  <body>

    <header>
      <h1>
        <?php 
          $welcome = "Let's get started with PHP!";
          echo $welcome;
        ?>
      </h1>
    </header>

    <?php include 'nav.php'; ?>

    <article>
      <p>Some simple things to do with PHP</p>

      <!-- print out text -->
      <p><?php echo "just the text..."; ?></p>
      <?php echo '<p>Hello World: I can print text and tags too!</p>'; ?> 
      
      <!-- print out what browser(s) are available on the server -->
      <?php
      echo $_SERVER['HTTP_USER_AGENT'];
      ?>

      <?php
        if (strpos($_SERVER['HTTP_USER_AGENT'], 'MSIE') !== FALSE) {
      ?>
        <p>You are using Internet Explorer</p>
      <?php
        } else {
      ?>
        <p>You are not using Internet Explorer</p>
      <?php
        }
      ?>

      <!-- You can also do math... -->
      <figure>
        <?php echo 50+3; ?><br/>
        <?php echo 100*4/7; ?><br/>
        <?php echo ((10000000000000000/1267545)*14)/123869715; ?>
      </figure>
      
    </article>

    <footer>
      <p>&copy; <?php echo date(Y); ?></p>
    </footer>

  </body>

</html>
