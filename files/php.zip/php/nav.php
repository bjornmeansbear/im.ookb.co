<nav>
  <ul>
    <li><a href="index.php">Home</a></li>
    <li><a href="about.php">About</a></li>
    <li><a href="contact.php">Contact</a></li>
    <li><a href="">Lorem</a></li>
    <li><a href="">Ipsum</a></li>
    <li><a href="">Dolor</a></li>
    <li><a href="">sit Amet</a></li>
  </ul>
</nav>