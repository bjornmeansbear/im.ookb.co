<!DOCTYPE html>

<!-- This is a PHP file, notice that it looks very similar to a regular HTML file � this is not always the case, but mostly is true when just working on theme-related endeavors.-->
<html>

  <head>
    <title>PHP Demo - Contact page!</title>
  </head>

  <body>

    <header>
      <h1>
        <?php 
          $welcome = "This is the Contact Page";
          echo $welcome;
        ?>
      </h1>
      <h2>
        <?php 
          $subhead = "And this was printed out by php";
          echo $subhead;
        ?>
      </h2>
    </header>

    <?php include 'nav.php'; ?>

    <article>
      <p>Some simple things to do with PHP</p>
    </article>

    <footer>
      <p>&copy; <?php echo date(Y); ?></p>
    </footer>

  </body>

</html>
