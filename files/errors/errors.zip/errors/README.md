# Startup and Go

This is a simple placeholder website for our group... more info will come as it grows. For now, this code base doesn't do much but create a website hosted with GitHub Pages.